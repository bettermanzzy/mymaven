package mymaven;

import org.junit.Test;

import static junit.framework.TestCase.assertEquals;

public class Testnewmaven{
   private newmaven nm = new newmaven();

   @Test
    public void testnewmaven() throws Exception{
        newmaven nm = new newmaven();
        assertEquals("my new maven !",nm.maven());
    }

}