package mymaven;

import com.sun.org.apache.xerces.internal.impl.xpath.XPath;

@myanno("my new maven !")
public class newmaven {
    private myanno myanno1 = newmaven.class.getAnnotation(myanno.class);
    private String str1 = myanno1.value();
    public static void main(String[] args){
        newmaven nw = new newmaven();
        System.out.println(nw.str1);
    }
    public String maven(){
        return str1;
    }
}
